 define("UsrPeriodicityEverydayConstant", [], function() {
	var periodicityEverydayId = "cc25db07-f4c3-4482-9fa3-9a40d5d79460";
	return {
		PeriodicityEverydayId: periodicityEverydayId
	};
});