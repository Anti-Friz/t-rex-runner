define("UsrConcertPrograms1Page", ["UsrPeriodicityEverydayConstant"], function(UsrPeriodicityEverydayConstant) {
	return {
		entitySchemaName: "UsrConcertPrograms",
		attributes: {
            "responseCollectionConcertPrograms": {
                "dataValueType": Terrasoft.DataValueType.INTEGER,
                "type": Terrasoft.ViewModelColumnType.VIRTUAL_COLUMN
            },
            "maximumDailyActiveConcertPrograms": {
                "dataValueType": Terrasoft.DataValueType.INTEGER,
                "type": Terrasoft.ViewModelColumnType.VIRTUAL_COLUMN
            }
		},
		modules: /**SCHEMA_MODULES*/{}/**SCHEMA_MODULES*/,
		details: /**SCHEMA_DETAILS*/{
			"Files": {
				"schemaName": "FileDetailV2",
				"entitySchemaName": "UsrConcertProgramsFile",
				"filter": {
					"masterColumn": "Id",
					"detailColumn": "UsrConcertPrograms"
				}
			},
			"UsrSchemaf501b119Detail08e06a02": {
				"schemaName": "UsrSchemaf501b119Detail",
				"entitySchemaName": "UsrConcertProgram",
				"filter": {
					"detailColumn": "UsrConcertProgram",
					"masterColumn": "Id"
				}
			}
		}/**SCHEMA_DETAILS*/,
		businessRules: /**SCHEMA_BUSINESS_RULES*/{}/**SCHEMA_BUSINESS_RULES*/,
		methods: {
			onEntityInitialized: function(){
                this.callParent(arguments);
                this.getPeriodicityActiveNumber();
                this.getMaximumDailyActiveConcertPrograms();
			},
			
			getPeriodicityActiveNumber: function() {
                var periodicity = UsrPeriodicityEverydayConstant.PeriodicityEverydayId;
                var esqPeriodicity = this.Ext.create("Terrasoft.EntitySchemaQuery", {
                    rootSchemaName: "UsrConcertPrograms"
                });
                //esqPeriodicity.addColumn("UsrName");
				esqPeriodicity.addAggregationSchemaColumn("UsrName", Terrasoft.AggregationType.COUNT, "UniqueConcertCount", Terrasoft.AggregationEvalType.DISTINCT);
                var groupFilters = this.Ext.create("Terrasoft.FilterGroup");
                var filterPerodicity = this.Terrasoft.createColumnFilterWithParameter(this.Terrasoft.ComparisonType.EQUAL, "UsrPereodicity.Id", periodicity);
                var thisId = this.get("Id");
                var filterId = this.Terrasoft.createColumnFilterWithParameter(this.Terrasoft.ComparisonType.NOT_EQUAL, "Id", thisId);
                var filterIsActive = this.Terrasoft.createColumnFilterWithParameter(this.Terrasoft.ComparisonType.EQUAL, "UsrIsActive", true);
                groupFilters.addItem(filterPerodicity);
                groupFilters.logicalOperation = this.Terrasoft.LogicalOperatorType.AND;
                groupFilters.addItem(filterIsActive);
                groupFilters.addItem(filterId);
                esqPeriodicity.filters.add(groupFilters);
                esqPeriodicity.getEntityCollection(function(result) {
                    if (!result.success) {
                        this.showInformationDialog("Request error");
                        return;
                    }
                    else {
                        //var lengthCollection = result.collection.collection.length;
                        //this.set("responseCollectionConcertPrograms", result.entity.get("UniqueConcertCount"));
						 this.set("responseCollectionConcertPrograms", result.collection.getByIndex(0).get("UniqueConcertCount"));
                    }
                }, this);
			},
			
			 setValidationConfig: function() {
                this.callParent(arguments);
                this.addColumnValidator("UsrPereodicity", this.periodicityValidator);
				this.addColumnValidator("UsrIsActive", this.isActivPeriodicityValidator);
            },
			 periodicityValidator: function() {
                var invalidMessage= "";
                var periodicity = this.get("UsrPereodicity");
				var peridicityId = periodicity.value;
                if (peridicityId===UsrPeriodicityEverydayConstant.PeriodicityEverydayId) {
                    var isActive = this.get("UsrIsActive");
                    if (isActive) {
                        var maxActivePrograms = this.get("maximumDailyActiveConcertPrograms");
               			var lengthCollection = this.get("responseCollectionConcertPrograms");
						if (lengthCollection >= maxActivePrograms) {
							invalidMessage = "Недостаточно концертных залов. Не больше, чем " + maxActivePrograms + " одновременных ежедневных программ."
		                }
                    }
                }
                	else {
                    invalidMessage = "";
                }
                return {
                    invalidMessage: invalidMessage
                };                
			}, 
			//Terrasoft.utils.showInformation("Недостаточно концертных залов. Не больше, чем " + maxActivePrograms + " одновременных ежедневных программ.");
			isActivPeriodicityValidator: function() {
				var invalidMessage= "";        
				var isActive = this.get("UsrIsActive");        
				if(isActive === true)
				{
					var periodicity = this.get("UsrPereodicity");
					if(periodicity.value === UsrPeriodicityEverydayConstant.PeriodicityEverydayId)
					{
						var maxActivePrograms = this.get("maximumDailyActiveConcertPrograms");
               			var lengthCollection = this.get("responseCollectionConcertPrograms");
						if (lengthCollection >= maxActivePrograms) {
							invalidMessage = "Недостаточно концертных залов. Не больше, чем " + maxActivePrograms + " одновременных ежедневных программ."
		                	Terrasoft.utils.showInformation(invalidMessage);
						}
					}
				}
                return {
                    invalidMessage: invalidMessage
                }; 
			},	 
             getMaximumDailyActiveConcertPrograms: function() {
                var callback = function(value) {
                     this.set("maximumDailyActiveConcertPrograms", value);
                };
                this.Terrasoft.SysSettings.querySysSettingsItem("MaxActiveEverydayConcertProgram", callback, this);
            }
		},
		dataModels: /**SCHEMA_DATA_MODELS*/{}/**SCHEMA_DATA_MODELS*/,
		diff: /**SCHEMA_DIFF*/[
			{
				"operation": "insert",
				"name": "UsrName58879b50-d91f-476e-8c92-d02420c4da67",
				"values": {
					"layout": {
						"colSpan": 24,
						"rowSpan": 1,
						"column": 0,
						"row": 0,
						"layoutName": "ProfileContainer"
					},
					"bindTo": "UsrName"
				},
				"parentName": "ProfileContainer",
				"propertyName": "items",
				"index": 0
			},
			{
				"operation": "insert",
				"name": "STRINGfbc066f6-7378-4a4c-8941-98d21812f9ee",
				"values": {
					"layout": {
						"colSpan": 24,
						"rowSpan": 1,
						"column": 0,
						"row": 1,
						"layoutName": "ProfileContainer"
					},
					"bindTo": "UsrCode",
					"enabled": true
				},
				"parentName": "ProfileContainer",
				"propertyName": "items",
				"index": 1
			},
			{
				"operation": "insert",
				"name": "LOOKUP9787e2a9-b437-4367-adf6-1e08dd595773",
				"values": {
					"layout": {
						"colSpan": 12,
						"rowSpan": 1,
						"column": 0,
						"row": 0,
						"layoutName": "Header"
					},
					"bindTo": "UsrCollective",
					"enabled": true,
					"contentType": 5
				},
				"parentName": "Header",
				"propertyName": "items",
				"index": 0
			},
			{
				"operation": "insert",
				"name": "STRING75e2e149-e9bd-4537-b673-cd161c3ab544",
				"values": {
					"layout": {
						"colSpan": 12,
						"rowSpan": 1,
						"column": 12,
						"row": 0,
						"layoutName": "Header"
					},
					"bindTo": "UsrResponsible",
					"enabled": true
				},
				"parentName": "Header",
				"propertyName": "items",
				"index": 1
			},
			{
				"operation": "insert",
				"name": "LOOKUP4fe2c74a-fca6-402c-9dce-7b269197c292",
				"values": {
					"layout": {
						"colSpan": 12,
						"rowSpan": 1,
						"column": 0,
						"row": 1,
						"layoutName": "Header"
					},
					"bindTo": "UsrPereodicity",
					"enabled": true,
					"contentType": 3
				},
				"parentName": "Header",
				"propertyName": "items",
				"index": 2
			},
			{
				"operation": "insert",
				"name": "BOOLEAN36448923-83a7-4ac9-aab1-a7930056d9ab",
				"values": {
					"layout": {
						"colSpan": 12,
						"rowSpan": 1,
						"column": 12,
						"row": 1,
						"layoutName": "Header"
					},
					"bindTo": "UsrIsActive",
					"enabled": true
				},
				"parentName": "Header",
				"propertyName": "items",
				"index": 3
			},
			{
				"operation": "insert",
				"name": "STRINGe1e63e04-662d-45a1-ba51-d1d40fd5bd79",
				"values": {
					"layout": {
						"colSpan": 24,
						"rowSpan": 1,
						"column": 0,
						"row": 2,
						"layoutName": "Header"
					},
					"bindTo": "UsrComment",
					"enabled": true
				},
				"parentName": "Header",
				"propertyName": "items",
				"index": 4
			},
			{
				"operation": "insert",
				"name": "Tabc371cbecTabLabel",
				"values": {
					"caption": {
						"bindTo": "Resources.Strings.Tabc371cbecTabLabelTabCaption"
					},
					"items": [],
					"order": 0
				},
				"parentName": "Tabs",
				"propertyName": "tabs",
				"index": 0
			},
			{
				"operation": "insert",
				"name": "UsrSchemaf501b119Detail08e06a02",
				"values": {
					"itemType": 2,
					"markerValue": "added-detail"
				},
				"parentName": "Tabc371cbecTabLabel",
				"propertyName": "items",
				"index": 0
			},
			{
				"operation": "merge",
				"name": "ESNTab",
				"values": {
					"order": 1
				}
			}
		]/**SCHEMA_DIFF*/
	};
});
