define("UsrConcertPrograms81db69a3Section", [], function() {
	return {
		entitySchemaName: "UsrConcertPrograms",
		details: /**SCHEMA_DETAILS*/{}/**SCHEMA_DETAILS*/,
		diff: /**SCHEMA_DIFF*/[]/**SCHEMA_DIFF*/,
		methods: {}
	};
});
